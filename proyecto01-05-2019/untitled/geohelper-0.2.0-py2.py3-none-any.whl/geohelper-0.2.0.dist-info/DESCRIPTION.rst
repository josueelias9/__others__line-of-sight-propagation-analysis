Geohelper is a package that exposes several functions for calculating
geographical values such as distance and bearing between two points.  In the future,
additional functionality will be added to support geographical applications.

